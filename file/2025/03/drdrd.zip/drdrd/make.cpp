#include <cstdio>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <vector>
#include <sstream>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#define pb push_back
#define mp make_pair
#define ST begin()
#define ED end()
#define XX first
#define YY second
#define elif else if 
#define foreach(i,x) for (__typeof((x).ST) i=(x).ST;i!=(x).ED;++i) 
using namespace std;

typedef long long ll;
typedef long double ld;
typedef vector<int> vci;
typedef vector<string> vcs;
typedef pair<int,int> PII;

int Rand(int n)
{
	return ((rand()<<14)+rand())%n;
}

void work(int n,int p,int q)
{
	int n1=n/2+Rand(n/2),n2=n/2+Rand(n/2);
	for (int i=0;i<n1;++i)
		printf("%c",'a'+Rand(p)+q);
	printf("\n");
	for (int i=0;i<n2;++i)
		printf("%c",'a'+Rand(p)+q);
	printf("\n");
}

void make(int t,int n)
{
	char nm[100]="drdrd0.in";
	nm[5]+=t;
	freopen(nm,"w",stdout);
	printf("a\nab\nb\nab\nca\nab\nac\nba\nab\na\nab\nb\na\nb\n");
	work(n,3,0);
	work(n,3,23);
	work(n,26,0);
}

int main()
{
	srand(time(0));
	make(0,5);
	make(1,8);
	make(2,10);
	make(3,678);
	make(4,789);
	make(5,987);
	make(6,999);
	make(7,1000);
	make(8,1000);
	make(9,1000);

	return 0;
}
