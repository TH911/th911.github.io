#include <cstdio>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <vector>
#include <sstream>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#define pb push_back
#define mp make_pair
#define ST begin()
#define ED end()
#define XX first
#define YY second
#define elif else if 
#define foreach(i,x) for (__typeof((x).ST) i=(x).ST;i!=(x).ED;++i) 
using namespace std;

typedef long long ll;
typedef long double ld;
typedef vector<int> vci;
typedef vector<string> vcs;
typedef pair<int,int> PII;

const int N=1005;

char a[N],b[N];
int n,m;
int f[N][N];

void up(int &x,int y) {if (y<x) x=y;}

int main()
{
	freopen("drdrd9.in","r",stdin);
	freopen("drdrd9.out","w",stdout);

	while (~scanf("%s%s",a,b))
	{
		n=strlen(a);
		m=strlen(b);
		memset(f,1,sizeof f);
		for (int i=0;i<=n;++i)
			f[i][0]=0;
		for (int i=0;i<=n;++i)
			for (int j=0;j<m;++j) if (f[i][j]<=m)
			{
				up(f[i][j+1],f[i][j]+1);
				if (i<n) up(f[i+1][j+1],f[i][j]+(a[i]!=b[j]));
				if (i<n) up(f[i+1][j],f[i][j]+1);
			}
		int ans=m+1;
		for (int i=0;i<=n;++i) up(ans,f[i][m]);
			printf("%d\n",ans);
	}

	return 0;
}
