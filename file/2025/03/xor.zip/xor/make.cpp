#include <stdio.h>
#include <time.h>
#include <stdlib.h>
const int nmax = 100000, kmax = 1000000000;

int n, k;

int rd(int mo)
{
    return abs(rand() * rand() * rand() ) % mo;
}

int rd2(int mo)
{
    return abs(1LL * rand() * rand() * rand()) % mo;
}

int main()
{
    freopen("xor.in", "w", stdout);
    srand((unsigned)time(NULL));
    n = rd(nmax) + 1;
    k = rd2(kmax) + 1;
    printf("%d %d\n", n, k);
    for (int i = 1; i <= n; ++i)
	printf("%d ", rd(kmax));
    return 0;
}

