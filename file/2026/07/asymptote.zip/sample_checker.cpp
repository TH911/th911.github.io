#include <bits/stdc++.h>
#define fo(i,l,r) for(int i(l); i<=(r); ++i)
#define pb push_back
using namespace std;
const int N=105;
const int dx[4]={1,-1,0,0},dy[4]={0,0,1,-1};
int n,a[N][N];
vector<array<int,2>> p;
int cnt;
void dfs(int x,int y) {
	if(x<1||x>n||y<1||y>n) return ;
	p.pb({x,y});
	for(auto [i,j] : p) cout<<a[i][j]<<' '; cout<<'\n';
	++cnt;
	fo(i,0,3) {
		int xx=x+dx[i],yy=y+dy[i];
		if(a[xx][yy]<a[x][y]) continue;
		dfs(xx,yy);
	}
	p.pop_back();
}
int main() {
	cin>>n;
	fo(i,1,n) fo(j,1,n) cin>>a[i][j];
	fo(i,0,n+1) a[i][0]=a[i][n+1]=a[0][i]=a[n+1][i]=1e9;
	fo(i,1,n) fo(j,1,n) if(a[i][j]<min(min(a[i-1][j],a[i+1][j]),min(a[i][j-1],a[i][j+1]))) dfs(i,j);
	cout<<cnt<<'\n';
	return 0;
}